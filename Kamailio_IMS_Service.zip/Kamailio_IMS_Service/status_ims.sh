echo -n "=================  P-CSCF STATUS =======   " &   systemctl status pcscf_kamailio.service | grep --color=always Active:
echo -n "=================  S-CSCF STATUS =======   " &   systemctl status scscf_kamailio.service | grep --color=always Active:
echo -n "=================  I-CSCF STATUS =======   " &   systemctl status icscf_kamailio.service | grep --color=always Active:
echo -n "=================  HSS STATUS =======   " &   systemctl status hss.service | grep --color=always Active:
