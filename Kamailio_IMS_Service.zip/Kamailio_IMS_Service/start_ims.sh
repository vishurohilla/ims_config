systemctl stop pcscf_kamailio.service
systemctl stop scscf_kamailio.service
systemctl stop icscf_kamailio.service
systemctl stop hss.service

pkill -f kamailio

systemctl start pcscf_kamailio.service
systemctl start scscf_kamailio.service
systemctl start icscf_kamailio.service
systemctl start hss.service
