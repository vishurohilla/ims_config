# Kamailio - Serving-CSCF Example Configuration File

Project Website:

  * http://www.kamailio.org

## Database Structure

The necessary Database files for the Serving-CSCF can be found in the utils/kamctl/mysql/ folder.

The following tables (or files) are required:

  * ims_charging_create.sql
  * ims_dialog-create.sql
  * ms_usrloc_scscf-create.sql
  * presence-create.sql
  * standard-create.sql
